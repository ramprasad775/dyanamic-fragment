package com.example.staticanddynamicfragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class dynamicFragmentActvity extends AppCompatActivity {
 Button add,remove,replace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_fragment_actvity);
        add=(Button)findViewById(R.id.add);
        remove=(Button)findViewById(R.id.remove);
        replace=(Button)findViewById(R.id.replace);
        final dynamiclevelFragment2 dynamic_second_fragment=new dynamiclevelFragment2();
        final dynamiclevelFragment1 dynamic_first_fragment=new dynamiclevelFragment1();
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fragmentManager;
                Fragment first_dynamic_fragment;
                FragmentTransaction fragmentTransaction;
                fragmentManager=getSupportFragmentManager();
                first_dynamic_fragment=fragmentManager.findFragmentById(R.id.fragmentcontainer);
                if(first_dynamic_fragment==null)
                {
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.add(R.id.fragmentcontainer,dynamic_first_fragment);
                    fragmentTransaction.commit();
                }
                else if(first_dynamic_fragment==dynamic_first_fragment)
                {
                    Toast.makeText(dynamicFragmentActvity.this, "It is already displayed", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(dynamicFragmentActvity.this, "when any fragment is there it wont replace others", Toast.LENGTH_SHORT).show();
                }
            }
        });
        replace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager;
                Fragment second_dynamic_fragment;
                FragmentTransaction fragmentTransaction;
                fragmentManager=getSupportFragmentManager();
                second_dynamic_fragment=fragmentManager.findFragmentById(R.id.fragmentcontainer);
                if(second_dynamic_fragment==null)
                {
                    Toast.makeText(dynamicFragmentActvity.this, "there is no fragment so we cannot replace", Toast.LENGTH_SHORT).show();
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.add(R.id.fragmentcontainer,dynamic_first_fragment);
                    fragmentTransaction.commit();
                }
                else if(second_dynamic_fragment==dynamic_first_fragment)
                {
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragmentcontainer,dynamic_second_fragment);
                    fragmentTransaction.commit();
                }
                else
                {
                    Toast.makeText(dynamicFragmentActvity.this, "It is a already  replaced fragment", Toast.LENGTH_SHORT).show();
                }
            }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager;
                Fragment fragment;
                FragmentTransaction fragmentTransaction;
                fragmentManager=getSupportFragmentManager();
                fragment=fragmentManager.findFragmentById(R.id.fragmentcontainer);
                if(fragment==null)
                {
                    Toast.makeText(dynamicFragmentActvity.this, "It is empty there is no fragment to remove", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    fragmentTransaction=fragmentManager.beginTransaction();
                    fragmentTransaction.remove(fragment);
                    fragmentTransaction.commit();
                }
            }
        });
    }
}
